#exmaple of square

library(powerR)
square(3)
