#exmaple of biquadrates

library(powerR)
biquadrates(8)
