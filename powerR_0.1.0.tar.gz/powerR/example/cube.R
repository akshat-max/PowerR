#exmaple of cube

library(powerR)
cube(5)
